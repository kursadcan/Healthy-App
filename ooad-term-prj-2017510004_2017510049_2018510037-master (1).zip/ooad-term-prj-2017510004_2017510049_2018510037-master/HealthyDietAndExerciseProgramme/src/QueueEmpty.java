
public class QueueEmpty extends Exception 
{	//Throws exception 
	public QueueEmpty()
	{
		super();
		System.err.println("Queue is empty");
	}
}
